import os
import sqlite3
from datetime import datetime, date
from flask import Flask, render_template, request, redirect, url_for, g

app = Flask(__name__)
DATABASE = 'attendance.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS employee (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                department TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id INTEGER NOT NULL,
                date TEXT NOT NULL,
                status TEXT NOT NULL,
                FOREIGN KEY (employee_id) REFERENCES employee (id)
            )
        ''')
        db.commit()

        # Seed sample data if empty
        cursor.execute("SELECT COUNT(*) FROM employee")
        if cursor.fetchone()[0] == 0:
            cursor.executemany('''
                INSERT INTO employee (name, department, email) VALUES (?, ?, ?)
            ''', [
                ('Alice Smith', 'Engineering', 'alice@company.com'),
                ('Bob Jones', 'Marketing', 'bob@company.com'),
                ('Charlie Brown', 'HR', 'charlie@company.com')
            ])
            db.commit()

            today_str = str(date.today())
            cursor.executemany('''
                INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, ?)
            ''', [
                (1, today_str, 'Present'),
                (2, today_str, 'Late'),
                (3, today_str, 'Absent')
            ])
            db.commit()

@app.route('/')
def index():
    db = get_db()
    cursor = db.cursor()

    cursor.execute("SELECT COUNT(*) FROM employee")
    total_employees = cursor.fetchone()[0]

    today_str = str(date.today())
    cursor.execute("SELECT status, COUNT(*) FROM attendance WHERE date = ? GROUP BY status", (today_str,))
    status_counts = dict(cursor.fetchall())
    
    present_count = status_counts.get('Present', 0)
    absent_count = status_counts.get('Absent', 0)
    late_count = status_counts.get('Late', 0)

    cursor.execute("SELECT * FROM employee ORDER BY id ASC")
    employees = cursor.fetchall()

    cursor.execute('''
        SELECT a.id, a.date, a.status, e.name as employee_name, e.department
        FROM attendance a
        JOIN employee e ON a.employee_id = e.id
        ORDER BY a.date DESC, a.id DESC
    ''')
    attendances = cursor.fetchall()

    return render_template('index.html',
                           total_employees=total_employees,
                           present_count=present_count,
                           absent_count=absent_count,
                           late_count=late_count,
                           employees=employees,
                           attendances=attendances,
                           today=today_str)

@app.route('/add_employee', methods=['POST'])
def add_employee():
    name = request.form.get('name')
    department = request.form.get('department')
    email = request.form.get('email')
    if name and department and email:
        db = get_db()
        try:
            db.execute("INSERT INTO employee (name, department, email) VALUES (?, ?, ?)", (name, department, email))
            db.commit()
        except sqlite3.IntegrityError:
            pass
    return redirect(url_for('index'))

@app.route('/mark_attendance', methods=['POST'])
def mark_attendance():
    emp_id = request.form.get('employee_id')
    status = request.form.get('status')
    att_date = request.form.get('date', str(date.today()))
    
    if emp_id and status:
        db = get_db()
        db.execute("INSERT INTO attendance (employee_id, date, status) VALUES (?, ?, ?)", (int(emp_id), att_date, status))
        db.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)
